/****************************************************************************
* Author: Muhammad Rafi                                                    *
* Purpose: DynamicSafeArray (Examples)                                     *
* Dated: September 18, 2007                                                *
* Version: 1.0                                                             *                                                 
* Last modified: September 27, 2007                                        *
****************************************************************************/

#include<iostream>
#include<fstream>
#include <stdio.h>
#include <string.h>
#include<cstdlib>

using namespace std;

class ArrayIndexOutOfBoundException {
public:
	ArrayIndexOutOfBoundException()
		: message ("Array Index Out of Bound") {}
	~ArrayIndexOutOfBoundException() { /*delete message; */}
	const string what() const { return message; }
private:
	char *message;
};

class DynamicSafeArray{
	
	 private:
	 	int *Data;
	 	int size;
	 	
	 	
	public:
		DynamicSafeArray(){
			
			Data=NULL;
			size=0;
			
			
		}
	
    	DynamicSafeArray(int n){
			
			size=n;
			Data= new int[size];
			memset(this->Data, 0, sizeof(int)*size);
					
			
		}
		
		
	   DynamicSafeArray(const DynamicSafeArray & rhs){
			
			 this->size= rhs.size;
			 this->Data= new int[size];
			 memcpy(this->Data,rhs.Data,(sizeof(int)*rhs.getSize()));
			
		}
		
       ~DynamicSafeArray()
	   {
	    	if(Data !=0)
	    	{
			
		    	delete [] Data;
		    	Data=0;
		    	size=0;
		   }
		
    	}
    	
    	void ReSize(int nSize){
    		
    		if (size != nSize )  
			{
			 int * temp= new int[size];
			 	
			    for(int i=0; i<size ; i++){
			    	
			    	temp[i]= *(Data+i);
			    }
			    delete[] Data;
			    Data=0;
			    
			    Data = new int[nSize];
			    memset(this->Data, 0, sizeof(int)*nSize);
  				for(int i=0; i<size ; i++){
			    	
			    	*(Data+i)=temp[i];
			    }
			    size= nSize;
			    delete [] temp;
			    temp=0;
  	
				
			} 		
    		
    	}
	
	   
	 unsigned int getSize() const {
	 
	   return size;
	 }
	
	
	DynamicSafeArray& operator=( DynamicSafeArray & rhs)
     {
         if (this  != &rhs)
        {
               
        int s=rhs.getSize(); 
        this->size=s;
        this->Data= new int[s];
        memcpy(this->Data,rhs.Data, sizeof(rhs.Data));
        }
        return (*this);
         
     }

	//lval
	 int& operator[](unsigned int i){ 
	 
	  return *(Data+i);}
	 
	 //rval
	const int& operator[](unsigned int i) const {  
	return *(Data+i);}



friend istream& operator >> (istream& infile, DynamicSafeArray & rhs)
{
	for (int count=0;count<rhs.size;count++)
		infile>>rhs.Data[count];
    return infile;
}

friend ostream& operator << (ostream& outfile,DynamicSafeArray & rhs)
{
	for (int count=0;count<rhs.size;count++)
		outfile<<rhs.Data[count];
    return outfile;
}


};


int main()
{
  
  DynamicSafeArray DSA1(10); 
  
  
  cout << "Enter an Array DSA1: ";
  cin >> DSA1;
  cout << DSA1;
  
   std::ofstream out_file;
   out_file.open("output.txt");
   out_file << DSA1<< endl;
   out_file.close();
  

return 0;


}
